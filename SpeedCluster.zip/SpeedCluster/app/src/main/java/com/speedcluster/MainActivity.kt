package com.speedcluster

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.min
import kotlin.math.roundToInt

private val BG = Color.parseColor("#0A0E13")
private val PANEL = Color.parseColor("#10171F")
private val LINE = Color.parseColor("#1F2B37")
private val INK = Color.parseColor("#E8EEF4")
private val DIM = Color.parseColor("#8593A3")
private val ACCENT = Color.parseColor("#3FD8C9")
private val ON_ACCENT = Color.parseColor("#04211E")
private val CRIT = Color.parseColor("#FF4D57")
private val ON_CRIT = Color.parseColor("#17060A")

private const val KMH = 3.6f
private const val MPH = 2.236936f

/** The round speedometer: a 270 degree arc, a red zone above the limit, the speed in the middle. */
class GaugeView(context: Context) : View(context) {
    private var shown = 0f
    private var limit = 50
    private var label = "km/h"
    private var over = false
    private var animator: ValueAnimator? = null
    private val rect = RectF()

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = LINE
    }
    private val zone = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = CRIT
        alpha = 120
    }
    private val prog = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = DIM
    }

    fun update(value: Float, lim: Int, lab: String, isOver: Boolean) {
        limit = lim
        label = lab
        over = isOver
        animator?.cancel()
        if (abs(value - shown) < 0.05f) {
            shown = value
            invalidate()
            return
        }
        val a = ValueAnimator.ofFloat(shown, value)
        a.duration = 450
        a.addUpdateListener {
            shown = it.animatedValue as Float
            invalidate()
        }
        animator = a
        a.start()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val dia = w * 0.86f
        val stroke = dia * 0.07f
        val r = dia / 2f - stroke / 2f
        val h = (r + stroke + r * 0.8f + stroke).toInt()
        setMeasuredDimension(w, h)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val dia = w * 0.86f
        val stroke = dia * 0.07f
        val r = dia / 2f - stroke / 2f
        val cx = w / 2f
        val cy = r + stroke
        val base = if (label == "mph") 80 else 120
        val gMax = maxOf(base, (ceil(limit * 1.6 / 20.0) * 20).toInt()).toFloat()

        track.strokeWidth = stroke
        zone.strokeWidth = stroke
        prog.strokeWidth = stroke
        rect.set(cx - r, cy - r, cx + r, cy + r)

        c.drawArc(rect, 135f, 270f, false, track)
        if (limit < gMax) {
            c.drawArc(rect, 135f + 270f * limit / gMax, 270f * (gMax - limit) / gMax, false, zone)
        }
        val sweep = 270f * min(shown, gMax) / gMax
        if (sweep > 1f) {
            prog.color = if (over) CRIT else ACCENT
            c.drawArc(rect, 135f, sweep, false, prog)
        }

        num.color = if (over) CRIT else INK
        num.textSize = dia * 0.34f
        val numY = cy + num.textSize * 0.3f
        c.drawText(shown.roundToInt().toString(), cx, numY, num)
        small.textSize = dia * 0.075f
        c.drawText(label.uppercase(), cx, numY + small.textSize * 1.6f, small)
        c.drawText("LIMIT $limit", cx, cy + r * 0.78f, small)
    }
}

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var gauge: GaugeView
    private lateinit var statusTv: TextView
    private lateinit var alertTv: TextView
    private lateinit var statsTv: TextView
    private lateinit var startBtn: Button
    private lateinit var limitTv: TextView
    private lateinit var calibTv: TextView
    private lateinit var unitBtn: Button
    private lateinit var soundBtn: Button
    private var testTone: ToneGenerator? = null

    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun shape(fill: Int, radius: Int, stroke: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(fill)
        d.cornerRadius = dp(radius).toFloat()
        if (stroke != 0) d.setStroke(dp(1), stroke)
        return d
    }

    private fun lp(w: Int, h: Int, top: Int = 0, weight: Float = 0f, left: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, weight)
        p.topMargin = dp(top)
        p.leftMargin = dp(left)
        return p
    }

    private fun button(label: String, primary: Boolean = false): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 15f
        b.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        b.setTextColor(if (primary) ON_ACCENT else INK)
        b.background = if (primary) shape(ACCENT, 12) else shape(PANEL, 12, LINE)
        b.minimumHeight = dp(52)
        b.minHeight = dp(52)
        b.stateListAnimator = null
        return b
    }

    private fun label(text: String, color: Int, size: Float, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(color)
        t.textSize = size
        if (bold) t.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        return t
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(28), dp(16), dp(28))
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        scroll.isFillViewport = true
        scroll.addView(root, ViewGroup.LayoutParams(match, wrap))

        val title = label("SPEED CLUSTER", INK, 18f, true)
        title.letterSpacing = 0.1f
        root.addView(title, lp(match, wrap))

        statusTv = label("", DIM, 13f)
        root.addView(statusTv, lp(match, wrap, 4))

        gauge = GaugeView(this)
        root.addView(gauge, lp(match, wrap, 12))

        alertTv = label("", INK, 16f, true)
        alertTv.gravity = Gravity.CENTER
        alertTv.setPadding(dp(16), dp(12), dp(16), dp(12))
        root.addView(alertTv, lp(match, wrap, 4))

        statsTv = label("", DIM, 14f)
        statsTv.gravity = Gravity.CENTER
        root.addView(statsTv, lp(match, wrap, 12))

        startBtn = button("Start tracking", true)
        root.addView(startBtn, lp(match, wrap, 16))

        root.addView(label("Alarm limit", DIM, 13f), lp(match, wrap, 20))
        val limitRow = LinearLayout(this)
        limitRow.orientation = LinearLayout.HORIZONTAL
        limitRow.gravity = Gravity.CENTER_VERTICAL
        val minus = button("-")
        val plus = button("+")
        limitTv = label("50", INK, 26f, true)
        limitTv.gravity = Gravity.CENTER
        limitRow.addView(minus, lp(dp(64), wrap))
        limitRow.addView(limitTv, lp(0, wrap, 0, 1f))
        limitRow.addView(plus, lp(dp(64), wrap))
        root.addView(limitRow, lp(match, wrap, 6))

        root.addView(label("Speed calibration (match your car's speedometer)", DIM, 13f), lp(match, wrap, 18))
        val calRow = LinearLayout(this)
        calRow.orientation = LinearLayout.HORIZONTAL
        calRow.gravity = Gravity.CENTER_VERTICAL
        val calMinus = button("-")
        val calPlus = button("+")
        calibTv = label("0%", INK, 26f, true)
        calibTv.gravity = Gravity.CENTER
        calRow.addView(calMinus, lp(dp(64), wrap))
        calRow.addView(calibTv, lp(0, wrap, 0, 1f))
        calRow.addView(calPlus, lp(dp(64), wrap))
        root.addView(calRow, lp(match, wrap, 6))
        calMinus.setOnClickListener { changeCalib(-1) }
        calPlus.setOnClickListener { changeCalib(1) }

        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        unitBtn = button("")
        soundBtn = button("")
        row2.addView(unitBtn, lp(0, wrap, 0, 1f))
        row2.addView(soundBtn, lp(0, wrap, 0, 1f, 10))
        root.addView(row2, lp(match, wrap, 14))

        val row3 = LinearLayout(this)
        row3.orientation = LinearLayout.HORIZONTAL
        val testBtn = button("Test alarm")
        val resetBtn = button("Reset trip")
        row3.addView(testBtn, lp(0, wrap, 0, 1f))
        row3.addView(resetBtn, lp(0, wrap, 0, 1f, 10))
        root.addView(row3, lp(match, wrap, 10))

        startBtn.setOnClickListener {
            if (SpeedState.running) stopTracking() else ensureAndStart()
        }
        minus.setOnClickListener { changeLimit(-5) }
        plus.setOnClickListener { changeLimit(5) }
        unitBtn.setOnClickListener { toggleUnit() }
        soundBtn.setOnClickListener {
            prefs.edit().putBoolean("sound", !prefs.getBoolean("sound", true)).apply()
            refresh()
        }
        testBtn.setOnClickListener { testBeep() }
        resetBtn.setOnClickListener {
            SpeedState.resetTrip()
            refresh()
        }

        setContentView(scroll)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        SpeedState.listener = { refresh() }
        refresh()
    }

    override fun onPause() {
        SpeedState.listener = null
        super.onPause()
    }

    override fun onDestroy() {
        try {
            testTone?.release()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    private fun ensureAndStart() {
        val needed = ArrayList<String>()
        needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        needed.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startTracking() else requestPermissions(missing.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            startTracking()
        } else {
            Toast.makeText(this, "Allow precise location to track your speed", Toast.LENGTH_LONG).show()
        }
    }

    private fun startTracking() {
        startForegroundService(Intent(this, SpeedService::class.java))
        SpeedState.running = true
        refresh()
    }

    private fun stopTracking() {
        stopService(Intent(this, SpeedService::class.java))
        SpeedState.running = false
        SpeedState.over = false
        SpeedState.speedMs = 0f
        refresh()
    }

    private fun changeLimit(delta: Int) {
        val v = (prefs.getInt("limit", 50) + delta).coerceIn(5, 300)
        prefs.edit().putInt("limit", v).apply()
        refresh()
    }

    private fun changeCalib(delta: Int) {
        val v = (prefs.getInt("calib", 0) + delta).coerceIn(-20, 30)
        prefs.edit().putInt("calib", v).apply()
        refresh()
    }

    private fun toggleUnit() {
        val mph = prefs.getString("unit", "kmh") == "mph"
        val lim = prefs.getInt("limit", 50)
        val converted = (if (mph) lim * 1.609344 else lim * 0.621371).roundToInt().coerceIn(5, 300)
        prefs.edit()
            .putString("unit", if (mph) "kmh" else "mph")
            .putInt("limit", converted)
            .apply()
        refresh()
    }

    private fun testBeep() {
        try {
            if (testTone == null) testTone = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            testTone?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 400)
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot play sound", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refresh() {
        val mph = prefs.getString("unit", "kmh") == "mph"
        val mult = scaledMult(prefs)
        val calib = prefs.getInt("calib", 0)
        val unit = if (mph) "mph" else "km/h"
        val limit = prefs.getInt("limit", 50)
        val sound = prefs.getBoolean("sound", true)
        val running = SpeedState.running
        val over = running && SpeedState.over

        gauge.update(SpeedState.speedMs * mult, limit, unit, over)

        alertTv.text = if (over) {
            "SLOW DOWN - over $limit $unit"
        } else if (running) {
            "Within $limit $unit"
        } else {
            "Alarm armed above $limit $unit"
        }
        alertTv.setTextColor(if (over) ON_CRIT else INK)
        alertTv.background = shape(if (over) CRIT else PANEL, 24, if (over) CRIT else LINE)

        statusTv.text = if (!running) {
            "Not tracking"
        } else if (SpeedState.accuracy >= 0f) {
            "Tracking - GPS accuracy ${SpeedState.accuracy.roundToInt()} m"
        } else {
            "Tracking - searching for GPS..."
        }

        val dist = SpeedState.distM / 1000f * (if (mph) 0.621371f else 1f)
        statsTv.text = "Top ${(SpeedState.maxMs * mult).roundToInt()} $unit   -   Trip ${"%.1f".format(dist)} ${if (mph) "mi" else "km"}"

        limitTv.text = limit.toString()
        calibTv.text = if (calib > 0) "+$calib%" else "$calib%"
        unitBtn.text = "Units: $unit"
        soundBtn.text = if (sound) "Alarm sound: On" else "Alarm sound: Off"
        startBtn.text = if (running) "Stop tracking" else "Start tracking"
    }
}
