package com.speedcluster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import kotlin.math.min
import kotlin.math.roundToInt

/** Shared between the service and the screen. Everything runs on the main thread. */
object SpeedState {
    @Volatile var running = false
    @Volatile var speedMs = 0f
    @Volatile var accuracy = -1f
    @Volatile var over = false
    @Volatile var maxMs = 0f
    @Volatile var distM = 0f
    var listener: (() -> Unit)? = null

    fun notifyChanged() {
        listener?.invoke()
    }

    fun resetTrip() {
        maxMs = 0f
        distM = 0f
    }
}

/** Metres per second to the chosen unit, scaled by the calibration percentage (match the car's speedometer). */
fun scaledMult(sp: SharedPreferences): Float {
    val base = if (sp.getString("unit", "kmh") == "mph") 2.236936f else 3.6f
    return base * (1f + sp.getInt("calib", 0) / 100f)
}

class SpeedService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var lm: LocationManager? = null
    private var tone: ToneGenerator? = null
    private var alarming = false
    private var prev: Location? = null
    private var lastFixAt = 0L
    private var lastShown = -1

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            onLoc(location)
        }

        override fun onProviderEnabled(provider: String) {}

        override fun onProviderDisabled(provider: String) {}

        @Suppress("OVERRIDE_DEPRECATION")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    private val beeper = object : Runnable {
        override fun run() {
            try {
                tone?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 350)
            } catch (e: Exception) {
            }
            handler.postDelayed(this, 700)
        }
    }

    /** If GPS goes quiet for 10 seconds, treat the car as stopped so the alarm does not hang. */
    private val watchdog = object : Runnable {
        override fun run() {
            if (SystemClock.elapsedRealtime() - lastFixAt > 10000 && SpeedState.speedMs != 0f) {
                SpeedState.speedMs = 0f
                evaluate()
                updateNotification()
                SpeedState.notifyChanged()
            }
            handler.postDelayed(this, 2000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        tone = try {
            ToneGenerator(AudioManager.STREAM_ALARM, 100)
        } catch (e: RuntimeException) {
            null
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Speed tracking", NotificationManager.IMPORTANCE_LOW)
        )
        val n = buildNotification("Waiting for GPS")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIF_ID, n)
        }

        SpeedState.running = true
        SpeedState.speedMs = 0f
        SpeedState.accuracy = -1f
        SpeedState.over = false
        lastFixAt = SystemClock.elapsedRealtime()
        prev = null
        lastShown = -1

        try {
            val manager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm = manager
            manager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper()
            )
        } catch (e: SecurityException) {
            stopSelf()
            return START_NOT_STICKY
        } catch (e: RuntimeException) {
            stopSelf()
            return START_NOT_STICKY
        }

        handler.removeCallbacks(watchdog)
        handler.postDelayed(watchdog, 2000)
        SpeedState.notifyChanged()
        return START_STICKY
    }

    private fun onLoc(loc: Location) {
        val p = prev
        var v: Float = if (loc.hasSpeed()) {
            loc.speed
        } else if (p != null && loc.time > p.time) {
            p.distanceTo(loc) / ((loc.time - p.time) / 1000f)
        } else {
            0f
        }
        if (!loc.hasSpeed() && loc.hasAccuracy() && loc.accuracy > 80f) {
            SpeedState.accuracy = loc.accuracy
            SpeedState.notifyChanged()
            return
        }
        prev = loc
        if (v < 0.7f) v = 0f
        if (v > 100f) v = 100f

        val now = SystemClock.elapsedRealtime()
        val dt = min(5f, (now - lastFixAt) / 1000f)
        SpeedState.distM = SpeedState.distM + v * dt
        lastFixAt = now

        SpeedState.speedMs = v
        if (v > SpeedState.maxMs) SpeedState.maxMs = v
        if (loc.hasAccuracy()) SpeedState.accuracy = loc.accuracy

        evaluate()
        updateNotification()
        SpeedState.notifyChanged()
    }

    /** Alarm rule: on above the limit, off once back at limit minus one. Reads settings live. */
    private fun evaluate() {
        val sp = getSharedPreferences("prefs", MODE_PRIVATE)
        val limit = sp.getInt("limit", 50)
        val mult = scaledMult(sp)
        val sound = sp.getBoolean("sound", true)
        val v = (SpeedState.speedMs * mult).roundToInt()
        if (!SpeedState.over && v > limit) {
            SpeedState.over = true
        } else if (SpeedState.over && v <= limit - 1) {
            SpeedState.over = false
        }
        if (SpeedState.over && sound) startAlarm() else stopAlarm()
    }

    private fun startAlarm() {
        if (alarming) return
        alarming = true
        handler.post(beeper)
    }

    private fun stopAlarm() {
        if (!alarming) return
        alarming = false
        handler.removeCallbacks(beeper)
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Speed Cluster")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification() {
        val sp = getSharedPreferences("prefs", MODE_PRIVATE)
        val mph = sp.getString("unit", "kmh") == "mph"
        val mult = scaledMult(sp)
        val label = if (mph) "mph" else "km/h"
        val shown = (SpeedState.speedMs * mult).roundToInt()
        val key = shown * 2 + (if (SpeedState.over) 1 else 0)
        if (key == lastShown) return
        lastShown = key
        val suffix = if (SpeedState.over) " - over the limit" else ""
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification("$shown $label$suffix"))
    }

    override fun onDestroy() {
        try {
            lm?.removeUpdates(listener)
        } catch (e: Exception) {
        }
        handler.removeCallbacksAndMessages(null)
        alarming = false
        try {
            tone?.release()
        } catch (e: Exception) {
        }
        tone = null
        SpeedState.running = false
        SpeedState.over = false
        SpeedState.speedMs = 0f
        SpeedState.notifyChanged()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "speed"
        private const val NOTIF_ID = 1
    }
}
